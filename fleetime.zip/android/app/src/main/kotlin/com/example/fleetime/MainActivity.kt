package com.example.fleetime

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
